"""Model parameters.

IMPORTANT -- the thesis does NOT publish the geometric and inertial data of
the instrumented 2004 Honda CBR600RR.  Only a handful of numbers appear in
the text (total mass 270 kg, wheel spin inertias, tyre radii/profiles, drag
fit).  Everything else in :func:`cbr600rr_estimate` is an engineering
estimate built from public CBR600RR data (wheelbase, rake, trail) and typical
supersport values.  Replace them with measured data when available.

Symbols follow the thesis (Fig. 4.24, List of Notations).  All lengths in m,
angles in rad, SI units throughout.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
import numpy as np

# order of the geometric parameters handed to the generated kinematics code
GEOM_ORDER = ["Ra", "Px", "Pz", "Py", "Hx", "Hz", "Qx", "Qz", "Bx", "Bz",
              "Cx", "Cz", "Fx", "Fz", "Rx", "Rz", "eps",
              "Rf", "rhof", "Rr", "rhor",
              "bf1", "bf2", "bf3", "cf1", "cf2", "cf3",
              "br1", "br2", "br3", "cr1", "cr2", "cr3"]

# Tyre profile polynomials of Section 5.5, eqs. (5.18)/(5.19), Tables 5.9/5.10:
#   y(gamma) = b1 g^5 + b2 g^3 + b3 g          (lateral, sign of the thesis)
#   z(gamma) = c1 g^6 + c2 g^4 + c3 g^2 + c4   (radius to the contact point)
PROFILE_THESIS = dict(
    front=dict(b=(-6.188e-3, 1.954e-2, -6.240e-2), c=(-1.320e-2, 2.487e-2, -3.755e-2, 0.3034)),
    rear=dict(b=(-3.936e-2, 5.961e-2, -0.1109), c=(-3.133e-2, 2.816e-2, -5.060e-2, 0.3202)),
)


@dataclass
class BikeParams:
    # ---- geometry (Fig. 4.24) -------------------------------------------
    Ra: float      # swing-arm length, rear axle -> pivot P (along b1)
    Px: float      # pivot P -> main frame mass centre A, along a1
    Pz: float      #                                         along a2
    Hx: float      # A -> steering head point H, along a1
    Hz: float      #                              along a2
    Qx: float      # H -> Q perpendicular to steering axis (fork offset), f1
    Qz: float      # H -> Q along steering axis f2 (negative: Q below H)
    Bx: float      # P -> swing-arm mass centre, along b1 (negative: rearwards)
    Bz: float      #                              along b2
    Cx: float      # front axle G -> fork-lower mass centre C, along f1
    Cz: float      #                                            along f2
    Fx: float      # H -> steering assembly mass centre F, along f1
    Fz: float      #                                        along f2
    Rx: float      # A -> aerodynamic centre of pressure R, along a1
    Rz: float      #                                         along a2
    eps: float     # steering head (caster) angle
    Rf: float      # front tyre unloaded radius (crown centre line)
    rhof: float    # front tyre crown radius of the toroidal part (0 = none)
    Rr: float      # rear tyre unloaded radius
    rhor: float    # rear tyre crown radius of the toroidal part
    Py: float = 0.0   # lateral offset of A (rider hang-off, Section 4.6: A_y)
    # Tyre profile.  Contact point in the wheel frame at camber gamma:
    #   T_y = rho sin(g) + (B1 g^5 + B2 g^3 + B3 g)        towards the lean side
    #   T_z = R + rho (cos(g) - 1) + (C1 g^6 + C2 g^4 + C3 g^2)
    # A torus has B = C = 0; the measured profile of Section 5.5 has rho = 0,
    # B = -b (thesis sign) and C = c.
    bf1: float = 0.0
    bf2: float = 0.0
    bf3: float = 0.0
    cf1: float = 0.0
    cf2: float = 0.0
    cf3: float = 0.0
    br1: float = 0.0
    br2: float = 0.0
    br3: float = 0.0
    cr1: float = 0.0
    cr2: float = 0.0
    cr3: float = 0.0
    # ---- masses ----------------------------------------------------------
    MA: float = 0.0   # main frame, engine, rider
    MB: float = 0.0   # swing-arm
    MC: float = 0.0   # fork lower (unsprung)
    MD: float = 0.0   # rear wheel
    MF: float = 0.0   # steering assembly (fork upper, bars, forearms)
    MG: float = 0.0   # front wheel
    # ---- inertia tensors about the mass centres, in the body frames ------
    # (axis 1 fwd, 2 up, 3 right;  wheels: axis 3 is the spin axis)
    IA: np.ndarray = field(default_factory=lambda: np.zeros((3, 3)))
    IB: np.ndarray = field(default_factory=lambda: np.zeros((3, 3)))
    IC: np.ndarray = field(default_factory=lambda: np.zeros((3, 3)))
    ID: np.ndarray = field(default_factory=lambda: np.zeros((3, 3)))
    IF: np.ndarray = field(default_factory=lambda: np.zeros((3, 3)))
    IG: np.ndarray = field(default_factory=lambda: np.zeros((3, 3)))
    # ---- travel limits (used by the suspension force models) -------------
    fork_travel: float = 0.120      # q1 in [0, fork_travel]; 0 = bottomed
    q2_top: float = 0.0             # swing-arm angle at full extension
    q2_bottom: float = 0.0          # swing-arm angle fully compressed
    g: float = 9.81

    # ------------------------------------------------------------------
    def geom(self) -> np.ndarray:
        return np.array([getattr(self, k) for k in GEOM_ORDER], dtype=float)

    def profile(self, which, gamma):
        """Contact point co-ordinates (T_y, T_z) of the 'front' / 'rear' tyre
        at camber angle gamma (T_y positive towards the lean side)."""
        f = which[0]
        R, rho = (self.Rf, self.rhof) if f == "f" else (self.Rr, self.rhor)
        b = [getattr(self, f"b{f}{i}") for i in (1, 2, 3)]
        c = [getattr(self, f"c{f}{i}") for i in (1, 2, 3)]
        g = gamma
        Ty = rho * np.sin(g) + b[0] * g**5 + b[1] * g**3 + b[2] * g
        Tz = R + rho * (np.cos(g) - 1) + c[0] * g**6 + c[1] * g**4 + c[2] * g**2
        return Ty, Tz

    @property
    def total_mass(self) -> float:
        return self.MA + self.MB + self.MC + self.MD + self.MF + self.MG

    def copy(self, **changes) -> "BikeParams":
        d = {k: (v.copy() if isinstance(v, np.ndarray) else v)
             for k, v in asdict(self).items()}
        d.update(changes)
        return BikeParams(**d)


def cbr600rr_estimate(profile: str = "measured") -> tuple[BikeParams, dict]:
    """Estimated parameter set for a 2004 CBR600RR with rider (270 kg).

    Returns ``(params, design)`` where ``design`` holds the nominal static
    configuration the geometry was built around (q1, q2 at mu = 0 with
    undeflected tyres).

    From the thesis:   total mass 270 kg (Sec. 4.5.5); wheel spin inertias
                       0.484 / 0.638 kg m^2 (Sec. 4.5.5); tyre radii
                       303.2 / 320.4 mm and profile points (Sec. 5.5,
                       Table 5.6 -> crown radii by circle fit).
    Public data:       wheelbase 1.390 m, rake 24 deg, trail 95 mm,
                       120 mm fork travel.
    Sharp et al. 2004: wheel diametral inertias 0.270 / 0.383 kg m^2 (the
                       thesis' spin inertias are the values of that paper).
    Everything else:   ESTIMATED.

    profile = 'measured'  tyre profile polynomials of Tables 5.9 / 5.10
              'torus'     circle through tread edge and crown of Table 5.6
    """
    W, eps, trail = 1.390, np.radians(24.0), 0.095
    Rf, Rr = 0.3032, 0.3204
    prof = {}
    if profile == "measured":
        pf, pr = PROFILE_THESIS["front"], PROFILE_THESIS["rear"]
        Rf, Rr = pf["c"][3], pr["c"][3]
        for t, d in (("f", pf), ("r", pr)):
            for i in range(3):
                prof[f"b{t}{i+1}"] = -d["b"][i]
                prof[f"c{t}{i+1}"] = d["c"][i]
    # crown radius of a circle through tread edge and crown (Table 5.6):
    # front half-width 59.5 mm, crown height 49.5 mm; rear 92.0 / 56.0 mm
    rhof = (59.5**2 + 49.5**2) / (2 * 49.5) * 1e-3     # 0.0605 m
    rhor = (92.0**2 + 56.0**2) / (2 * 56.0) * 1e-3     # 0.1036 m
    if profile == "measured":
        rhof = rhor = 0.0

    Ra = 0.560                 # swing-arm length                  (estimate)
    zP = 0.410                 # pivot height at static trim       (estimate)
    xA, zA = 0.700, 0.660      # frame+engine+rider mass centre    (estimate)
    zH = 0.860                 # height of steering head point H   (estimate)
    q1s = 0.085                # static fork extension (35 mm sag) (estimate)

    q2s = np.arcsin((zP - Rr) / Ra)
    xP = Ra * np.cos(q2s)
    xH = (W + trail) - zH * np.tan(eps)
    Qx = Rf * np.sin(eps) - trail * np.cos(eps)        # eq. (4.25) inverted
    e2 = np.array([-np.sin(eps), np.cos(eps)])
    Qz = float((np.array([W, Rf]) - np.array([xH, zH])) @ e2 + q1s)

    rear_travel = 0.130        # axle travel                       (estimate)
    rear_sag = 0.030
    q2_top = q2s + rear_sag / Ra
    q2_bottom = q2_top - rear_travel / Ra

    def diag(a, b, c):
        return np.diag([a, b, c]).astype(float)

    p = BikeParams(
        Ra=Ra, Px=xA - xP, Pz=zA - zP, Hx=xH - xA, Hz=zH - zA,
        Qx=Qx, Qz=Qz,
        Bx=-0.300, Bz=0.000,
        Cx=-0.010, Cz=0.120,
        Fx=0.020, Fz=-0.100,
        Rx=0.080, Rz=0.060,
        eps=eps, Rf=Rf, rhof=rhof, Rr=Rr, rhor=rhor,
        MA=219.0, MB=8.0, MC=7.0, MD=14.5, MF=10.0, MG=11.5,   # sum = 270
        IA=diag(13.0, 20.0, 28.0),
        IB=diag(0.05, 0.35, 0.35),
        IC=diag(0.10, 0.05, 0.10),
        ID=diag(0.383, 0.383, 0.638),     # spin inertia from the thesis
        IF=diag(0.25, 0.10, 0.20),
        IG=diag(0.27, 0.27, 0.484),       # spin inertia from the thesis
        fork_travel=0.120, q2_top=q2_top, q2_bottom=q2_bottom, **prof,
    )
    design = dict(q1=q1s, q2=q2s, wheelbase=W, trail=trail)
    return p, design
