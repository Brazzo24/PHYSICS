"""Whipple benchmark bicycle of Meijaard, Papadopoulos, Ruina & Schwab (2007)
(thesis ref. [2], Section 2.1) expressed in the 11-d.o.f. motorcycle model.

Used as an independent check of the lateral dynamics: with knife-edge wheels,
locked suspension and very stiff linear tyres the motorcycle model must
reproduce the published eigenvalues (weave, capsize, castering).
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import least_squares

from .params import BikeParams
from .kinematics import make_q, NQ
from .model import Motorcycle, make_inputs, IIN
from .frames import Rz

# published eigenvalues at v = 5 m/s and critical speeds (Table 2 of the paper)
WEAVE_5 = complex(-0.77534188219585, 4.46486771378823)
CAPSIZE_5 = -0.32286642900409
CASTER_5 = -14.07838969279822
V_WEAVE, V_CAPSIZE = 4.29238253634111, 6.02426201426100


def benchmark_params():
    """Benchmark bicycle mapped onto the bodies of the motorcycle model.
    Returns (BikeParams, design dict with q1, q2)."""
    w, c, lam, g = 1.02, 0.08, np.pi / 10, 9.81
    rR, rF = 0.3, 0.35
    Ra, q1s = 0.30, 0.05                     # dummy swing-arm / fork extension
    xP, zP = Ra, rR                          # swing-arm horizontal, q2 = 0
    xA, zA = 0.3, 0.9                        # rear body B of the paper
    zH = 0.9
    xH = (w + c) - zH * np.tan(lam)
    e1 = np.array([np.cos(lam), np.sin(lam)]); e2 = np.array([-np.sin(lam), np.cos(lam)])
    dG = np.array([w, rF]) - np.array([xH, zH])
    dF = np.array([0.9, 0.7]) - np.array([xH, zH])
    # inertia tensors: paper axes (x fwd, z down) -> model axes (1 fwd, 2 up, 3 right)
    IA = np.array([[9.2, -2.4, 0], [-2.4, 2.8, 0], [0, 0, 11.0]])
    IH = np.array([[0.05892, 0.00756, 0], [0.00756, 0.00708, 0], [0, 0, 0.06]])
    R = Rz(lam)                              # F axes in the frame axes
    tiny = np.diag([1e-6, 1e-6, 1e-6])
    p = BikeParams(
        Ra=Ra, Px=xA - xP, Pz=zA - zP, Hx=xH - xA, Hz=zH - zA,
        Qx=float(dG @ e1), Qz=float(dG @ e2 + q1s),
        Bx=-0.1, Bz=0.0, Cx=0.0, Cz=0.0,
        Fx=float(dF @ e1), Fz=float(dF @ e2), Rx=0.0, Rz=0.0,
        eps=lam, Rf=rF, rhof=0.0, Rr=rR, rhor=0.0,
        MA=85.0, MB=1e-6, MC=1e-6, MD=2.0, MF=4.0, MG=3.0,
        IA=IA, IB=tiny, IC=tiny, ID=np.diag([0.0603, 0.0603, 0.12]),
        IF=R.T @ IH @ R, IG=np.diag([0.1405, 0.1405, 0.28]),
        fork_travel=0.1, q2_top=0.1, q2_bottom=-0.1, g=g)
    return p, dict(q1=q1s, q2=0.0)


class StiffForces:
    """Locks fork and swing-arm with stiff spring/dampers; gravity."""
    def __init__(self, p, design, k=2e7, c=2e4):
        self.p, self.d, self.k, self.c = p, design, k, c

    def inputs(self, t, kk, damping=True):
        q, u = kk["q"], kk["u"]
        return make_inputs(g=self.p.g,
                           Ffork=self.k * (self.d["q1"] - q[0]) - self.c * u[0],
                           Tsay=self.k * (self.d["q2"] - q[1]) - self.c * u[1])


class StiffLinearTyres:
    """Linear slip tyres, stiff enough to approximate rolling without slip."""
    def __init__(self, kz=2e7, cz=2e4, C=2e6):
        self.kz, self.cz, self.C = kz, cz, C

    def steady(self, k):
        u, q = k["u"], k["q"]
        res = {}
        for name, pt, ax, car, Rg, i in (("front", "S", "G", "F", k["R_H"], 2),
                                          ("rear", "T", "D", "B", k["R_M"], 3)):
            r = k["r_" + pt] - k["r_" + ax]
            v_mat = k["Jv_" + pt] @ u
            v_c = k["Jv_" + ax] @ u + np.cross(k["w_" + car], r)
            Vx = max(abs(v_c @ Rg[:, 0]), 0.1)
            res[name] = dict(Fx=-self.C * (v_mat @ Rg[:, 0]) / Vx, Fy=-self.C * (v_c @ Rg[:, 2]) / Vx,
                             Fz=self.kz * q[i] + self.cz * u[i], Vx=Vx, t=0.0)
        return res

    def inputs(self, k, uin=None, forces=None):
        uin = make_inputs() if uin is None else uin
        st = self.steady(k)
        for name, pre in (("front", "Ffw"), ("rear", "Frw")):
            for comp in "xyz":
                uin[IIN[pre + comp]] = st[name]["F" + comp]
        return uin, st


def benchmark_system():
    from .analysis import BikeSystem
    p, d = benchmark_params()
    model = Motorcycle(p)
    sys_ = BikeSystem(model, StiffForces(p, d), StiffLinearTyres(), relaxation=False)
    return sys_, d


def straight_state(sys_, design, V):
    """Equilibrium state for straight running at speed V."""
    from .analysis import rolling_spin_rates
    m = sys_.model

    def res(z):
        q = make_q(q1=design["q1"] + z[0] * 1e-4, q2=design["q2"] + z[1] * 1e-4, q3=z[2] * 1e-4, q4=z[3] * 1e-4)
        k = m.config(q)
        uin, _ = sys_.inputs(0.0, k)
        return (m.input_matrix(k) @ uin)[:4], q
    sol = least_squares(lambda z: res(z)[0], np.zeros(4), xtol=1e-15, ftol=1e-15, gtol=1e-15)
    q = res(sol.x)[1]
    u = np.zeros(NQ); u[6] = V
    u = rolling_spin_rates(m.config(q, u), u)
    return np.concatenate([q, u, np.zeros(4)])


def lateral_eigenvalues(V, sys_=None, design=None, fmax=20.0):
    """Eigenvalues of the benchmark at speed V, without the stiff
    (suspension / tyre compliance) modes."""
    if sys_ is None:
        sys_, design = benchmark_system()
    lam, _, _ = sys_.modes(straight_state(sys_, design, V))
    return np.array(sorted([l for l in lam if 1e-3 < abs(l) < fmax], key=lambda l: (-l.real, l.imag)))
