"""Chapter 5 / Appendix A: Magic Formula tyre model (MF-Tyre/MF-Swift 6.2 form
as printed in the thesis), relaxation behaviour and the coupling to the
multibody model.

Sign conventions
----------------
The thesis takes the 120/70 and 180/55 parameters of Sharp et al. (2004) and
*negates* pKy1 and pKy6.  The printed equations therefore work in the ISO
tyre system (y to the LEFT):

    kappa  = -V_sx / |V_x|                          (5.3)  + = driving
    alpha* = -V_sy / |V_x|,  V_sy measured to the RIGHT   (5.4)
    gamma  = camber, positive when the wheel leans to the RIGHT
    F_y(MF) positive to the LEFT

so with K_y_alpha < 0 a wheel sliding to the right is pushed to the left and
with K_y_gamma < 0 a wheel leaning to the right is pushed to the right.
:class:`MagicFormula` returns exactly what the appendix equations give;
:class:`TyreSet` converts to the model axes (force positive to the RIGHT,
along h3 / m3) by changing the sign of F_y.

Data sources: [T] thesis Tables 5.1-5.5, [S] Sharp, Evangelou & Limebeer,
Multibody Syst. Dyn. 12 (2004) Tables I-III and A.V, [E] estimate.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import numpy as np

from .model import make_inputs, IIN

_EPS = 1e-9


def _mf_sin(B, C, D, E, x):
    """Sine version of the Magic Formula (Section 5.3.1) without shifts."""
    Bx = B * x
    return D * np.sin(C * np.arctan(Bx - E * (Bx - np.arctan(Bx))))


def _mf_cos(B, C, E, x):
    """Cosine version (Section 5.3.2) with D = 1."""
    Bx = B * x
    return np.cos(C * np.arctan(Bx - E * (Bx - np.arctan(Bx))))


@dataclass
class MFParams:
    """Parameter set of one tyre.  Anything not listed is zero (shifts) or
    one (scale factors lambda, turn-slip factors zeta), as in Section 5.4."""
    name: str = ""
    Fz0: float = 1600.0        # nominal load
    R0: float = 0.32           # unloaded radius
    # --- longitudinal force (A.1)
    pCx1: float = 1.5
    pDx1: float = 1.0
    pDx2: float = 0.0
    pDx3: float = 0.0
    pEx1: float = 0.0
    pEx2: float = 0.0
    pEx3: float = 0.0
    pEx4: float = 0.0
    pKx1: float = 20.0
    pKx2: float = 0.0
    pKx3: float = 0.0
    pHx1: float = 0.0
    pHx2: float = 0.0
    pVx1: float = 0.0
    pVx2: float = 0.0
    rBx1: float = 10.0
    rBx2: float = 10.0
    rBx3: float = 0.0
    rCx1: float = 1.0
    rEx1: float = 0.0
    rEx2: float = 0.0
    rHx1: float = 0.0
    # --- lateral force (A.2)
    pCy1: float = 1.5
    pCy2: float = 0.0          # listed in Tables 5.2/5.4, not used in (A.3)
    pDy1: float = 1.0
    pDy2: float = 0.0
    pDy3: float = 0.0
    pEy1: float = 0.0
    pEy2: float = 0.0
    pEy3: float = 0.0
    pEy4: float = 0.0
    pEy5: float = 0.0
    pKy1: float = -20.0
    pKy2: float = 2.0
    pKy3: float = 0.0
    pKy4: float = 2.0
    pKy5: float = 0.0
    pKy6: float = -1.0
    pKy7: float = 0.0
    pHy1: float = 0.0
    pHy2: float = 0.0
    pVy1: float = 0.0
    pVy2: float = 0.0
    pVy3: float = 0.0
    pVy4: float = 0.0
    rBy1: float = 7.0
    rBy2: float = 8.0
    rBy3: float = 0.0
    rBy4: float = 0.0
    rCy1: float = 1.0
    rEy1: float = 0.0
    rEy2: float = 0.0
    rHy1: float = 0.0
    rHy2: float = 0.0
    rVy1: float = 0.0
    rVy2: float = 0.0
    rVy3: float = 0.0
    rVy4: float = 0.0
    rVy5: float = 0.0
    rVy6: float = 0.0
    # --- pneumatic trail (A.7)
    qBz1: float = 10.0
    qBz2: float = 0.0
    qBz3: float = 0.0
    qBz4: float = 0.0
    qBz5: float = 0.0
    qBz6: float = 0.0          # gamma^2 term of Sharp et al. / MF 6.2
    qCz1: float = 1.1
    qDz1: float = 0.2
    qDz2: float = 0.0
    qDz3: float = 0.0
    qDz4: float = 0.0
    qEz1: float = 0.0
    qEz2: float = 0.0
    qEz3: float = 0.0
    qEz4: float = 0.0
    qEz5: float = 0.0
    qHz1: float = 0.0
    qHz2: float = 0.0
    qHz3: float = 0.0
    qHz4: float = 0.0
    # --- residual aligning torque M_zr (A.6); off in the thesis (M_z = 0)
    qBz9: float = 0.0
    qBz10: float = 0.0
    qDz6: float = 0.0
    qDz7: float = 0.0
    qDz8: float = 0.0
    qDz9: float = 0.0
    qDz10: float = 0.0
    qDz11: float = 0.0
    # --- overturning moment (A.4), not used by the model
    qsx12: float = 0.0
    qsx13: float = 0.0
    qsx14: float = 0.0
    # --- relaxation (A.6): carcass stiffness at nominal load
    Cx0: float = 300.0e3
    Cy0: float = 110.0e3
    pcfx1: float = 0.0
    pcfx2: float = 0.0
    pcfy1: float = 0.0
    pcfy2: float = 0.0
    # --- radial stiffness / damping for the vertical force
    kz: float = 130.0e3
    cz: float = 250.0

    def copy(self, **kw):
        d = dict(self.__dict__); d.update(kw)
        return MFParams(**d)


class MagicFormula:
    """Steady-state Magic Formula of Appendix A (inflation pressure at its
    nominal value, no turn slip)."""

    def __init__(self, params: MFParams):
        self.p = params

    # ---- A.1 ---------------------------------------------------------
    def _fx_pure(self, kappa, gamma, Fz):
        p = self.p
        dfz = (Fz - p.Fz0) / p.Fz0
        SHx = p.pHx1 + p.pHx2 * dfz
        kx = kappa + SHx
        Cx = p.pCx1
        mux = (p.pDx1 + p.pDx2 * dfz) * (1 - p.pDx3 * gamma**2)
        Dx = mux * Fz
        Ex = np.minimum((p.pEx1 + p.pEx2 * dfz + p.pEx3 * dfz**2) * (1 - p.pEx4 * np.sign(kx)), 1.0)
        Kxk = Fz * (p.pKx1 + p.pKx2 * dfz) * np.exp(p.pKx3 * dfz)
        Bx = Kxk / (Cx * Dx + _EPS)
        SVx = Fz * (p.pVx1 + p.pVx2 * dfz)
        return _mf_sin(Bx, Cx, Dx, Ex, kx) + SVx, Kxk, mux

    def _gxa(self, kappa, alpha, gamma, Fz):
        p = self.p
        dfz = (Fz - p.Fz0) / p.Fz0
        B = (p.rBx1 + p.rBx3 * gamma**2) * np.cos(np.arctan(p.rBx2 * kappa))
        C, E, SH = p.rCx1, p.rEx1 + p.rEx2 * dfz, p.rHx1
        return _mf_cos(B, C, E, alpha + SH) / _mf_cos(B, C, E, SH)

    # ---- A.2 ---------------------------------------------------------
    def stiffness(self, gamma, Fz):
        """Cornering stiffness K_y_alpha and camber stiffness K_y_gamma0
        (both negative with the thesis parameters, see module docstring)."""
        p = self.p
        dfz = (Fz - p.Fz0) / p.Fz0
        Kya = p.pKy1 * p.Fz0 * np.sin(p.pKy4 * np.arctan(Fz / ((p.pKy2 + p.pKy5 * gamma**2) * p.Fz0))) \
            * (1 - p.pKy3 * np.abs(gamma))
        Kyg0 = (p.pKy6 + p.pKy7 * dfz) * Fz
        return Kya, Kyg0

    def _fy_pure(self, alpha, gamma, Fz):
        p = self.p
        dfz = (Fz - p.Fz0) / p.Fz0
        Kya, Kyg0 = self.stiffness(gamma, Fz)
        Kya_ = np.where(np.abs(Kya) < _EPS, -_EPS, Kya)
        muy = (p.pDy1 + p.pDy2 * dfz) * (1 - p.pDy3 * gamma**2)
        Cy, Dy = p.pCy1, muy * Fz
        SVyg = Fz * (p.pVy3 + p.pVy4 * dfz) * gamma
        SVy = Fz * (p.pVy1 + p.pVy2 * dfz) + SVyg
        SHy = (p.pHy1 + p.pHy2 * dfz) + (Kyg0 * gamma - SVyg) / Kya_
        ay = alpha + SHy
        Ey = np.minimum((p.pEy1 + p.pEy2 * dfz)
                        * (1 + p.pEy5 * gamma**2 - (p.pEy3 + p.pEy4 * gamma) * np.sign(ay)), 1.0)
        By = Kya / (Cy * Dy + _EPS)
        return _mf_sin(By, Cy, Dy, Ey, ay) + SVy, dict(Kya=Kya, By=By, Cy=Cy, muy=muy, SHy=SHy, SVy=SVy)

    def _gyk(self, kappa, alpha, gamma, Fz, muy):
        p = self.p
        dfz = (Fz - p.Fz0) / p.Fz0
        B = (p.rBy1 + p.rBy4 * gamma**2) * np.cos(np.arctan(p.rBy2 * (alpha - p.rBy3)))
        C, E, SH = p.rCy1, p.rEy1 + p.rEy2 * dfz, p.rHy1 + p.rHy2 * dfz
        G = _mf_cos(B, C, E, kappa + SH) / _mf_cos(B, C, E, SH)
        DVyk = muy * Fz * (p.rVy1 + p.rVy2 * dfz + p.rVy3 * gamma) * np.cos(np.arctan(p.rVy4 * alpha))
        SVyk = DVyk * np.sin(p.rVy5 * np.arctan(p.rVy6 * kappa))
        return G, SVyk

    # ---- A.5 (pneumatic trail only) -----------------------------------
    def pneumatic_trail(self, kappa, alpha, gamma, Fz):
        """Pneumatic trail t, eq. (A.7).  The camber factors are taken with
        |gamma| and gamma^2 (symmetric tyre, as in Sharp et al.)."""
        p = self.p
        dfz = (Fz - p.Fz0) / p.Fz0
        _, aux = self._fy_pure(alpha, gamma, Fz)
        _, Kxk, _ = self._fx_pure(kappa, gamma, Fz)
        Bt = (p.qBz1 + p.qBz2 * dfz + p.qBz3 * dfz**2) \
            * (1 + p.qBz4 * gamma + p.qBz5 * np.abs(gamma) + p.qBz6 * gamma**2)
        Ct = p.qCz1
        Dt = Fz * (p.qDz1 + p.qDz2 * dfz) * (1 + p.qDz3 * np.abs(gamma) + p.qDz4 * gamma**2) * p.R0 / p.Fz0
        SHt = p.qHz1 + p.qHz2 * dfz + (p.qHz3 + p.qHz4 * dfz) * gamma
        at = alpha + SHt
        ateq = np.arctan(np.sqrt(np.tan(at)**2 + (Kxk / aux["Kya"])**2 * kappa**2)) * np.sign(at)
        Et = np.minimum((p.qEz1 + p.qEz2 * dfz + p.qEz3 * dfz**2)
                        * (1 + (p.qEz4 + p.qEz5 * gamma) * 2 / np.pi * np.arctan(Bt * Ct * at)), 1.0)
        return Dt * _mf_cos(Bt, Ct, Et, ateq) * np.cos(alpha)

    def residual_torque(self, alpha, gamma, Fz):
        """M_zr of (A.6) (camber-induced 'twisting torque'), returned in the
        convention of Sharp et al.: positive for positive camber, i.e. it
        tends to steer a wheel that leans to the right towards the right."""
        p = self.p
        dfz = (Fz - p.Fz0) / p.Fz0
        _, aux = self._fy_pure(alpha, gamma, Fz)
        Br = p.qBz9 + p.qBz10 * np.abs(aux["By"]) * aux["Cy"]
        ar = alpha + aux["SHy"] + aux["SVy"] / aux["Kya"]
        Dr = Fz * p.R0 * ((p.qDz6 + p.qDz7 * dfz) + (p.qDz8 + p.qDz9 * dfz) * gamma
                          + (p.qDz10 + p.qDz11 * dfz) * gamma * np.abs(gamma)) / np.sqrt(1 + alpha**2)
        return Dr * np.cos(np.arctan(Br * ar))

    # ---- public ---------------------------------------------------------
    def forces(self, kappa, alpha, gamma, Fz):
        """Combined-slip F_x (A.1) and F_y (A.2) in the tyre (ISO) system.
        ``alpha`` is the lateral slip alpha* = tan(slip angle)."""
        Fz = np.maximum(Fz, 0.0)
        Fx0, _, _ = self._fx_pure(kappa, gamma, Fz)
        Fy0, aux = self._fy_pure(alpha, gamma, Fz)
        Fx = Fx0 * self._gxa(kappa, alpha, gamma, Fz)
        G, SVyk = self._gyk(kappa, alpha, gamma, Fz, aux["muy"])
        Fy = G * Fy0 + SVyk
        live = Fz > 0
        return np.where(live, Fx, 0.0), np.where(live, Fy, 0.0)

    def camber_thrust(self, alpha, gamma, Fz):
        """Section 5.2.6: F_y(gamma) - F_y(gamma = 0) at the same slip."""
        return self.forces(0.0, alpha, gamma, Fz)[1] - self.forces(0.0, alpha, 0.0, Fz)[1]

    def overturning_moment(self, Fy, gamma, Fz):
        """Eq. (A.4); not applied in the model (Section 5.2.8)."""
        p = self.p
        return p.R0 * (Fy * (p.qsx13 + p.qsx14 * np.abs(gamma)) - Fz * p.qsx12 * gamma * np.abs(gamma))

    def relaxation_lengths(self, Fz, gamma=0.0):
        """delta_x = K_x_kappa / C_x, delta_y = |K_y_alpha| / C_y   (A.6)."""
        p = self.p
        dfz = (Fz - p.Fz0) / p.Fz0
        _, Kxk, _ = self._fx_pure(0.0, gamma, Fz)
        Kya, _ = self.stiffness(gamma, Fz)
        Cx = p.Cx0 * (1 + p.pcfx1 * dfz + p.pcfx2 * dfz**2)
        Cy = p.Cy0 * (1 + p.pcfy1 * dfz + p.pcfy2 * dfz**2)
        return Kxk / Cx, np.abs(Kya) / Cy


# --------------------------------------------------------------------------
# parameter sets
# --------------------------------------------------------------------------
_TRAIL_S = dict(   # [S] Table III; the thesis does not list its M_z parameters
    front=dict(qCz1=1.0917, qBz1=10.486, qBz2=-0.001154, qBz5=-0.68973, qBz6=1.0411,
               qDz1=0.19796, qDz2=0.06563, qDz3=0.2199, qDz4=0.21866,
               qEz1=-0.91586, qEz2=0.11625, qEz5=1.4387,
               qBz9=27.445, qBz10=-1.0792, qDz8=0.3682, qDz9=0.1218, qDz10=0.25439, qDz11=-0.17873),
    rear=dict(qCz1=1.3153, qBz1=10.041, qBz2=-1.61e-8, qBz5=-0.76784, qBz6=0.73422,
              qDz1=0.26331, qDz2=0.030987, qDz3=-0.62013, qDz4=0.98524,
              qEz1=-0.19924, qEz2=-0.017638, qEz5=3.6511,
              qBz9=16.39, qBz10=-0.35549, qDz8=0.50453, qDz9=0.36312, qDz10=-0.19168, qDz11=-0.40709))


def front_tyre(modified=True) -> MFParams:
    """Front 120/70: Tables 5.1 and 5.2 [T]; ``modified`` applies the
    optimised values of Table 5.5."""
    p = MFParams(
        name="front 120/70", Fz0=1100.0, R0=0.3034,                 # Fz0 [S]
        pCx1=1.50, pDx1=1.44, pDx2=-0.20, pDx3=0.10, pEx1=0.0263, pEx2=0.27056,
        pEx3=-0.0769, pEx4=0.50, pKx1=20.00, pKx2=-4.233, pKx3=0.3369,
        rBx1=13.476, rBx2=8.00, rCx1=1.1231,
        pCy1=1.6, pCy2=0.86765, pDy1=1.45, pEy1=-1.5, pEy2=-3.2068, pEy4=-3.998,
        pKy1=-22.841, pKy2=2.1578, pKy3=0.2, pKy4=2.0, pKy5=-0.22882,
        pKy6=-0.69677, pKy7=-0.03077, pVy3=-0.5,
        rBy1=5.00, rBy2=8.1697, rBy3=-0.05914, rCy1=1.0533, rVy5=1.00,
        Cx0=300e3,                 # [E]
        Cy0=1 / 8.633e-6,          # [S] sigma_y = K_y_alpha * 8.633e-6 at low speed
        kz=130e3, cz=250.0,        # [S] radial stiffness; damping [E]
        **_TRAIL_S["front"])
    if modified:                   # Table 5.5
        p = p.copy(pCy1=0.80, pDy1=1.67, pEy1=-2.25, pEy2=-1.60, pEy4=-6.00,
                   pKy1=-50.00, pKy2=1.00, pKy6=-0.90, pVy3=-0.56)
    return p


def rear_tyre(modified=True) -> MFParams:
    """Rear 180/55: Tables 5.3 and 5.4 [T]; ``modified`` applies Table 5.5."""
    p = MFParams(
        name="rear 180/55", Fz0=1600.0, R0=0.3202,
        pCx1=1.50, pDx1=1.50, pDx2=-0.20, pDx3=0.10, pEx1=0.0263, pEx2=0.27056,
        pEx3=-0.0769, pEx4=0.50, pKx1=25.94, pKx2=-4.233, pKx3=0.3369,
        rBx1=13.476, rBx2=11.354, rCx1=1.1231,
        pCy1=1.50, pCy2=0.61397, pDy1=1.56, pEy1=-0.94635, pEy2=-1.669, pEy4=-4.288,
        pEy5=2.00, pKy1=-26.601, pKy2=1.6935, pKy3=0.29113, pKy4=2.00, pKy5=0.18708,
        pKy6=-1.10, pKy7=0.013293, pVy3=-0.5,
        rBy1=7.7856, rBy2=8.1697, rBy3=-0.05914, rCy1=1.0533, rVy5=1.00,
        Cx0=350e3, Cy0=1 / 9.694e-6, kz=141e3, cz=250.0,
        **_TRAIL_S["rear"])
    if modified:
        p = p.copy(pKy2=1.60, pKy6=-0.75)
    return p


# --------------------------------------------------------------------------
# coupling to the multibody model
# --------------------------------------------------------------------------
@dataclass
class TyreSet:
    """Front and rear tyre acting on the motorcycle model.

    ``slips`` evaluates kappa, alpha*, camber and load from a configuration
    dict of :class:`okane.model.Motorcycle`; ``steady`` returns the
    steady-state forces; ``inputs`` adds them to an input vector.
    Aligning moment, eq. (A.6): M_z = -t F_y(gamma = 0) [+ M_zr].  The
    pneumatic trail t acts on the side-slip part of the lateral force only
    (F_y evaluated at zero camber); in model axes this is the moment
    t * F_y0 about the vertical (Tfwz / Trwz).  The residual torque M_zr is
    off by default (the thesis runs with M_z = 0 apart from the trail).
    """
    front: MagicFormula
    rear: MagicFormula
    v_low: float = 1.0            # speed below which slips are regularised
    use_trail: bool = True
    use_residual: bool = False

    @classmethod
    def thesis(cls, modified=True, **kw):
        return cls(MagicFormula(front_tyre(modified)), MagicFormula(rear_tyre(modified)), **kw)

    def slips(self, k):
        """Dict per wheel with Vx, Vsx, Vsy, kappa, alpha, gamma, Fz."""
        out = {}
        u, q = k["u"], k["q"]
        spec = (("front", self.front, "S", "G", "F", k["R_H"], k["gamma1"], q[2], u[2]),
                ("rear", self.rear, "T", "D", "B", k["R_M"], q[8], q[3], u[3]))
        for name, mf, pt, ax, carrier, Rg, gam, defl, ddefl in spec:
            ex, ey = Rg[:, 0], Rg[:, 2]                 # heading, right
            r = k["r_" + pt] - k["r_" + ax]
            v_mat = k["Jv_" + pt] @ u                   # wheel-fixed point (with spin)
            v_c = k["Jv_" + ax] @ u + np.cross(k["w_" + carrier], r)   # contact point, no spin
            Vx, Vsx, Vsy = v_c @ ex, v_mat @ ex, v_c @ ey
            den = max(abs(Vx), self.v_low)
            Fz = max(mf.p.kz * defl + mf.p.cz * ddefl, 0.0) if defl > 0 else 0.0
            out[name] = dict(Vx=Vx, Vsx=Vsx, Vsy=Vsy, kappa=-Vsx / den, alpha=-Vsy / den,
                             gamma=gam, Fz=Fz, mf=mf)
        return out

    def steady(self, k):
        """Steady-state forces in MODEL axes: Fx along the heading, Fy to the
        right, Fz up, Mz about the vertical (from the pneumatic trail)."""
        res = {}
        for name, s in self.slips(k).items():
            Fx, Fy_iso = s["mf"].forces(s["kappa"], s["alpha"], s["gamma"], s["Fz"])
            t, Fy0, Mzr = 0.0, 0.0, 0.0
            if s["Fz"] > 0:
                if self.use_trail:
                    t = float(s["mf"].pneumatic_trail(s["kappa"], s["alpha"], s["gamma"], s["Fz"]))
                    Fy0 = -float(s["mf"].forces(s["kappa"], s["alpha"], 0.0, s["Fz"])[1])
                if self.use_residual:
                    Mzr = float(s["mf"].residual_torque(s["alpha"], s["gamma"], s["Fz"]))
            # moment about the vertical (up): trail part minus twisting torque
            res[name] = dict(s, Fx=float(Fx), Fy=-float(Fy_iso), t=t, Fy0=Fy0, Mzr=Mzr,
                             Mz=t * Fy0 - Mzr)
        return res

    def inputs(self, k, uin=None, forces=None):
        """Write tyre forces into u_in.  ``forces`` = (Fx_f, Fy_f, Fx_r, Fy_r)
        overrides the steady-state shear forces (relaxation states)."""
        uin = make_inputs() if uin is None else uin
        st = self.steady(k)
        f, r = st["front"], st["rear"]
        if forces is not None:
            # the lag acts on the shear forces; the trail moment follows F_y
            for d, fx, fy in ((f, forces[0], forces[1]), (r, forces[2], forces[3])):
                scale = fy / d["Fy"] if abs(d["Fy"]) > 1e-9 else 1.0
                d["Mz"] = d["t"] * d["Fy0"] * scale - d["Mzr"]
                d["Fx"], d["Fy"] = fx, fy
        c = IIN
        uin[c["Ffwx"]], uin[c["Ffwy"]], uin[c["Ffwz"]] = f["Fx"], f["Fy"], f["Fz"]
        uin[c["Frwx"]], uin[c["Frwy"]], uin[c["Frwz"]] = r["Fx"], r["Fy"], r["Fz"]
        uin[c["Tfwz"]] += f["Mz"]
        uin[c["Trwz"]] += r["Mz"]
        return uin, st

    def relaxation_rates(self, st, forces):
        """d/dt of the lagged forces:  tau F_dot + F = F_ss,  tau = delta/|Vx|
        (Section 5.2.16)."""
        rates = []
        for name, i in (("front", 0), ("rear", 2)):
            s = st[name]
            dx, dy = s["mf"].relaxation_lengths(max(s["Fz"], 1.0), s["gamma"])
            v = max(abs(s["Vx"]), self.v_low)
            Fx_ss, Fy_ss = s.get("Fx_ss", s["Fx"]), s.get("Fy_ss", s["Fy"])
            rates += [(Fx_ss - forces[i]) * v / max(dx, 1e-3), (Fy_ss - forces[i + 1]) * v / max(dy, 1e-3)]
        return np.array(rates)
