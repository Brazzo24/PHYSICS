"""Verification tests.  Run with  pytest -q  from the repository root."""
import numpy as np
import pytest

from okane import pendulum as P
from okane import frames
from okane.params import cbr600rr_estimate
from okane.kinematics import Kinematics, make_q
from okane.model import Motorcycle, make_inputs, rk4, IIN
from okane.forces import ForceSet, Drag
from okane.analysis import static_trim, steady_turn

p, design = cbr600rr_estimate()                 # measured tyre profile (Sec. 5.5)
p_torus, _ = cbr600rr_estimate(profile="torus")  # geometrically exact profile
Q = make_q(q1=0.07, q2=0.12, q3=0.005, q4=0.006, q9=0.5, q10=0.3, q11=0.05,
           q7=3.0, q8=-2.0)
U = np.array([0.1, -0.2, 0.05, 0.03, -100, -95, 28, -9, 0.4, 0.3, -0.5])


# ---- chapter 3 -----------------------------------------------------------
@pytest.mark.parametrize("method", ["newton", "lagrange", "kane"])
def test_pendulum_methods_agree_with_eq_3_7(method):
    eqs = getattr(P, method)()
    eqs = eqs[0] if method == "kane" else eqs
    assert P.equivalent(eqs, P.thesis_eom())


# ---- kinematics ------------------------------------------------------------
def test_design_configuration():
    k = Kinematics(p).config(make_q(q1=design["q1"], q2=design["q2"]))
    assert abs(k["mu"]) < 1e-12
    assert k["wheelbase"] == pytest.approx(design["wheelbase"], abs=1e-9)
    assert k["trail"] == pytest.approx(design["trail"], abs=1e-9)


def test_contact_points_on_ground():
    k = Kinematics(p).config(Q)
    assert abs(k["r_S"][1]) < 1e-12 and abs(k["r_T"][1]) < 1e-12


def test_camber_and_kinematic_steer_formulas_are_exact():
    k = Kinematics(p).config(Q)
    assert k["gamma1"] == pytest.approx(frames.camber_thesis(Q[8], Q[10], p.eps, k["mu"]))
    assert k["delta_k"] == pytest.approx(frames.kin_steer_thesis(Q[8], Q[10], p.eps, k["mu"]))


def test_printed_H_coefficients_are_gradient_of_4_17():
    # the printed coefficients are expanded about q3 = q4 = 0
    K = Kinematics(p_torus)
    Q0 = Q.copy(); Q0[2] = Q0[3] = 0.0
    H = K.pitch(Q0, model="thesis")[1]
    pr = K.H_printed(Q0)
    for name, i in [("H1", 0), ("H2", 1), ("H3", 2), ("H4", 3), ("H9", 8), ("H11", 10)]:
        assert pr[name] == pytest.approx(H[i], rel=1e-10, abs=1e-12)
    assert pr["H"] == pytest.approx(K.mu_thesis(Q0))


def test_partial_velocities_by_finite_differences():
    m = Motorcycle(p)
    k = m.config(Q, U)
    h = 1e-6
    kp, km = m.config(Q + h * U), m.config(Q - h * U)
    for pt in "ABCDFGPHQR":
        assert np.allclose((kp["r_" + pt] - km["r_" + pt]) / (2 * h), k["v_" + pt], atol=1e-6)
    kp, km = m.config(Q + h * U, U), m.config(Q - h * U, U)
    for pt in "ABCDFG":
        assert np.allclose((kp["v_" + pt] - km["v_" + pt]) / (2 * h), k["ab_" + pt], atol=1e-4)


# ---- dynamics --------------------------------------------------------------
def test_mass_matrix_spd():
    m = Motorcycle(p)
    K = m.mass_matrix(m.config(Q, U))
    assert np.allclose(K, K.T, atol=1e-10)
    assert np.linalg.eigvalsh(K).min() > 0


def test_energy_conservation():
    m = Motorcycle(p_torus)
    kf, ks, kt = 20e3, 30e3, 180e3

    def inp(t, k):
        q = k["q"]
        return make_inputs(g=9.81, Ffork=kf * (0.12 - q[0]), Tsay=ks * (0.2 - q[1]),
                           Ffwz=kt * q[2], Frwz=kt * q[3])

    def E(x):
        k = m.config(x[:11], x[11:]); q = x[:11]
        return (m.kinetic_energy(k) + m.potential_energy(k) + 0.5 * kf * (0.12 - q[0])**2
                + 0.5 * ks * (0.2 - q[1])**2 + 0.5 * kt * (q[2]**2 + q[3]**2))
    u0 = np.zeros(11); u0[[4, 5]] = -60; u0[6] = 19
    u0[8], u0[9], u0[10], u0[0] = 0.8, 0.5, -0.6, 0.1
    x0 = np.concatenate([make_q(q1=0.08, q2=0.15, q3=0.004, q4=0.006, q9=0.2, q11=0.03), u0])
    _, X = rk4(lambda t, x: m.rhs(t, x, inp), 0, x0, 2.5e-4, 400)
    assert abs(E(X[-1]) - E(X[0])) < 1e-5 * 1.0       # of ~5e4 J


def test_static_wheel_loads_match_statics():
    m = Motorcycle(p); F = ForceSet.default(p)
    q, uin, res = static_trim(m, F)
    k = m.config(q)
    cg = m.kin.mass_centre(k)
    Fzf = p.total_mass * p.g * (cg[0] - k["r_T"][0]) / (k["r_S"][0] - k["r_T"][0])
    assert uin[IIN["Ffwz"]] == pytest.approx(Fzf, rel=1e-8)
    assert uin[IIN["Ffwz"]] + uin[IIN["Frwz"]] == pytest.approx(p.total_mass * p.g, rel=1e-8)
    assert np.abs(res).max() < 1e-6


def test_steady_turn_force_balance():
    m = Motorcycle(p); F = ForceSet.default(p)
    V, R = 30.0, 80.0
    s = steady_turn(m, F, V, R, "right")
    assert np.abs(s["residual"]).max() < 1e-9
    k, uin = s["k"], s["u_in"]
    w = s["yaw_rate"]
    cg = m.kin.mass_centre(k)
    centre = np.array([0.0, 0.0, -V / w])              # turn centre (psi = 0)
    a = -w**2 * (cg - centre) * np.array([1, 0, 1])    # centripetal acc. of c.g.
    Fsum = (uin[IIN["Ffwy"]] * k["R_H"][:, 2] + uin[IIN["Frwy"]] * k["R_M"][:, 2]
            + uin[IIN["Frwx"]] * k["R_M"][:, 0])
    assert np.allclose(Fsum[[0, 2]], p.total_mass * a[[0, 2]], rtol=1e-6, atol=1e-6)
    assert uin[IIN["Ffwz"]] + uin[IIN["Frwz"]] == pytest.approx(p.total_mass * p.g)
    assert s["q"][8] > np.arctan(V**2 / (p.g * R))     # tyre width: more lean


def test_state_space_reproduces_simplified_accelerations():
    m = Motorcycle(p)
    uin = make_inputs(g=9.81, Ffork=1000, Tsay=600, Ffwz=1300, Frwz=1300, Ffwy=500)
    ss = m.state_space(Q, U)
    x = np.empty(22); x[0::2], x[1::2] = U, Q
    w = np.array([U[8]**2, U[8] * U[9], U[8] * U[10], U[9] * U[10]])
    ud = (ss["A"] @ x + ss["B"] @ uin + ss["R"] @ w)[0::2]
    assert np.allclose(ud, m.accelerations_thesis(Q, U, uin), atol=1e-8)


def test_drag_numbers_of_section_4_5_5():
    d = Drag()
    assert d.CdA == pytest.approx(0.4078, abs=2e-4)
    assert d.mechanical(1.0) - d.mechanical(0.0) == pytest.approx(-0.7857, abs=1e-4)
    assert d.mechanical(0.0) == pytest.approx(-51.2, abs=0.02)


# ---- chapter 5: tyres ------------------------------------------------------
from okane.tyre import MagicFormula, TyreSet, front_tyre, rear_tyre
from okane.analysis import BikeSystem
from okane import benchmark


@pytest.mark.parametrize("make", [front_tyre, rear_tyre])
def test_magic_formula_basic_properties(make):
    T = MagicFormula(make())
    Fz = 1500.0
    # zero slip, zero camber -> no shear force (symmetric tyre, zero shifts)
    Fx, Fy = T.forces(0.0, 0.0, 0.0, Fz)
    assert abs(Fx) < 1e-9 and abs(Fy) < 1e-9
    # slopes at the origin are the slip stiffnesses
    h = 1e-6
    Kya, Kyg0 = T.stiffness(0.0, Fz)
    assert (T.forces(0, h, 0, Fz)[1] - T.forces(0, -h, 0, Fz)[1]) / (2 * h) == pytest.approx(Kya, rel=1e-4)
    assert (T.forces(0, 0, h, Fz)[1] - T.forces(0, 0, -h, Fz)[1]) / (2 * h) == pytest.approx(Kyg0, rel=1e-4)
    # friction limits: |F| <= mu Fz, combined slip reduces Fx
    k = np.linspace(-1, 1, 401)
    assert np.abs(T.forces(k, 0.0, 0.0, Fz)[0]).max() <= T.p.pDx1 * Fz * 1.2
    assert abs(T.forces(0.1, 0.1, 0.0, Fz)[0]) < abs(T.forces(0.1, 0.0, 0.0, Fz)[0])
    # antisymmetry of a symmetric tyre
    assert T.forces(0, 0.05, 0.3, Fz)[1] == pytest.approx(-T.forces(0, -0.05, -0.3, Fz)[1])
    # camber thrust pushes a right-leaning wheel to the right (ISO: Fy < 0)
    assert T.forces(0, 0, 0.5, Fz)[1] < 0


def test_benchmark_bicycle_eigenvalues():
    """Meijaard et al. (2007): weave, capsize, castering at 5 m/s."""
    sys_, d = benchmark.benchmark_system()
    lam = benchmark.lateral_eigenvalues(5.0, sys_, d)
    weave = lam[np.argmax(lam.imag)]
    real = np.sort(lam[np.abs(lam.imag) < 1e-9].real)
    assert weave == pytest.approx(benchmark.WEAVE_5, abs=3e-3)
    assert real[-1] == pytest.approx(benchmark.CAPSIZE_5, abs=1e-3)
    assert real[0] == pytest.approx(benchmark.CASTER_5, abs=1e-2)
    # weave speed: real part of the weave pair crosses zero
    lam = benchmark.lateral_eigenvalues(benchmark.V_WEAVE, sys_, d)
    assert abs(lam[np.argmax(lam.imag)].real) < 2e-3


def test_steady_cornering_with_tyres():
    m = Motorcycle(p); F = ForceSet.default(p)
    s = BikeSystem(m, F, TyreSet.thesis()).steady_state(20.0, np.radians(50))
    assert np.abs(s["residual"]).max() < 1e-9
    t = s["tyres"]
    assert s["yaw_rate"] < 0 and t["front"]["Fy"] > 0 and t["rear"]["Fy"] > 0     # right turn
    assert t["front"]["Fz"] + t["rear"]["Fz"] == pytest.approx(p.total_mass * p.g, rel=1e-9)
    assert s["Trwy"] < 0                       # drive torque needed: tyres dissipate
    assert np.allclose(m.rhs(0, s["x"][:22], lambda tt, k: s["u_in"])[11:][[0, 1, 2, 3, 4, 5, 8, 9, 10]], 0, atol=1e-6)


# ---- sections 4.12 / 4.13: controls -----------------------------------------
from okane import controls as ctl


def test_pid_and_shaper():
    pid = ctl.PID(2.0, 4.0, 0.5, dt=0.01, out_min=-1, out_max=1)
    assert pid.update(10.0) == 1.0 and pid.I == 0.0          # saturated: integrator frozen
    assert pid.update(0.1, d_meas=0.2) == pytest.approx(0.2 - 0.1)
    assert pid.I == pytest.approx(4.0 * 0.1 * 0.01)
    sh = ctl.SetpointShaper(rate=1.2, tau=0.15, dt=1 / 800)
    y = [sh.update(1.0) for _ in range(1600)]
    assert max(np.diff(y)) * 800 <= 1.2 + 1e-9 and y[-1] == pytest.approx(1.0, abs=1e-3)


def test_powertrain_table_6_1_and_map():
    pt = ctl.Powertrain()
    assert pt.ratio(1) == pytest.approx(76 / 36 * 32 / 12 * 42 / 14)
    assert pt.ratio(6) == pytest.approx(76 / 36 * 28 / 24 * 42 / 14)
    assert pt.engine_torque(12000, 1.0) == pytest.approx(63.0)
    assert pt.engine_torque(4000, 0.0) == pytest.approx(-7.5)
    assert pt.engine_torque(15500, 0.0) == pytest.approx(-23.0)
    assert pt.throttle_for(30.0, 9000) == pytest.approx(
        np.interp(30.0, pt.engine_torque(9000, np.linspace(0, 1, 201)), np.linspace(0, 1, 201)))
    assert pt.axle_torque(50.0, 2) < 0                     # drive torque is negative


def test_abs_example_of_section_4_13_2():
    """Slip -0.1, target -0.05, Kabs 2 -> factor 0.9; slip -0.2 -> 0.7."""
    a = ctl.ABS(Kabs=2.0, target_normal=-0.05, target_strict=-0.05)
    m = Motorcycle(p)
    q = make_q(q1=0.08, q2=0.15, q3=0.008, q4=0.008)
    for slip, factor in ((-0.1, 0.9), (-0.2, 0.7)):
        u = np.zeros(11); u[6] = 100.0
        k = m.config(q, u)
        rf = np.linalg.norm(k["r_G"] - k["r_S"])
        u[4] = -100.0 * (1 + slip) / rf
        a.active = False
        assert a.update(m.config(q, u), 1.0) == pytest.approx(factor, abs=2e-3)


def test_kalman_recursion_scalar():
    """Random walk observed directly: gain converges to the textbook value."""
    q, r = 0.01, 1.0
    kf = ctl.KalmanFilter([[1.0]], [[q]], [[r]])
    for _ in range(500):
        K = kf.gain(np.eye(1), np.eye(1))
    P = kf.P[0, 0]                                   # predicted covariance: P = P - P^2/(P+r) + q
    assert P == pytest.approx(P - P**2 / (P + r) + q)
    assert K[0, 0] == pytest.approx(P / (P + r), rel=1e-6)


def test_traction_control_reduces_torque_only_above_target():
    m = Motorcycle(p)
    q = make_q(q1=0.08, q2=0.15, q3=0.008, q4=0.008, q9=np.radians(40))
    u = np.zeros(11); u[6] = 20.0
    k = m.config(q, u); rr = np.linalg.norm(k["r_D"] - k["r_T"])
    tc = ctl.TractionControl(Ktc=600.0)
    u[5] = -20.0 / rr * 1.02
    assert tc.update(m.config(q, u), 50.0) == 50.0
    u[5] = -20.0 / rr * 1.15
    out = tc.update(m.config(q, u), 50.0)
    assert out == pytest.approx(50.0 - 600.0 * (tc.slip - 0.05), abs=1e-6) and out < 50.0
