"""Controlling the model (thesis Sections 4.7, 4.12, 4.13).

* :class:`PID`, :class:`SetpointShaper`, :class:`SpeedController`,
  :class:`RollController`  -- the two controllers used when the model is
  driven by test functions (Section 4.12, tests of Section 7.4).
* :class:`Powertrain`     -- engine torque map (Section 4.7) and gear ratios
  (Table 6.1): throttle + gear -> rear axle torque.
* :class:`TractionControl`, :class:`ABS` -- crash avoidance (Section 4.13).
* :class:`KalmanFilter`, :class:`GyroSteer`, :func:`run_observer` -- the model
  as an observer driven by recorded data (Fig. 4.36).
* :func:`simulate` -- discrete-time simulation loop at the thesis' 800 Hz:
  controllers are evaluated once per sample and their outputs held.

Sign reminders (see okane/model.py): a DRIVING rear axle torque Trwy is
negative, braking torques are positive, steering torque is positive to the
left, roll is positive to the right, forward wheel spin is negative.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import numpy as np

from .kinematics import NQ
from .model import IIN, NIN

FS = 800.0                      # sample rate of the thesis [Hz]


# --------------------------------------------------------------------------
# basic blocks
# --------------------------------------------------------------------------
class PID:
    """Discrete PID with derivative on the measurement and anti-windup
    (the integrator is frozen while the output is saturated or while the
    error is outside ``i_band``)."""

    def __init__(self, Kp, Ki=0.0, Kd=0.0, dt=1 / FS, out_min=-np.inf, out_max=np.inf,
                 i_band=np.inf):
        self.Kp, self.Ki, self.Kd, self.dt = Kp, Ki, Kd, dt
        self.out_min, self.out_max = out_min, out_max
        self.i_band = i_band            # integrate only while |error| <= i_band
        self.I = 0.0

    def reset(self):
        self.I = 0.0

    def update(self, error, d_meas=0.0):
        """error = set-point - measurement; d_meas = d(measurement)/dt."""
        u = self.Kp * error + self.I - self.Kd * d_meas
        u_sat = min(max(u, self.out_min), self.out_max)
        if abs(error) <= self.i_band and (u == u_sat or (u - u_sat) * error < 0):
            self.I += self.Ki * error * self.dt
        return u_sat


class SetpointShaper:
    """Rate limiter followed by a first-order low-pass (Section 7.4.2:
    1.2 rad/s and tau = 0.15 s for the roll angle)."""

    def __init__(self, rate, tau, dt=1 / FS, y0=0.0):
        self.rate, self.tau, self.dt = rate, tau, dt
        self.r = self.y = y0

    def update(self, target):
        self.r += np.clip(target - self.r, -self.rate * self.dt, self.rate * self.dt)
        self.y += self.dt / self.tau * (self.r - self.y)
        return self.y


def forward_speed(k):
    """M v_1^A: forward velocity of the main frame in the M frame."""
    return float((k["Jv_A"] @ k["u"]) @ k["R_M"][:, 0])


def body_rates(k):
    """Rate-gyro signals: angular velocity of the main frame about a1, a2, a3."""
    return k["R_A"].T @ k["w_A"]


class SpeedController:
    """PI controller on forward speed acting on the rear axle torque."""

    def __init__(self, Kp=60.0, Ki=20.0, dt=1 / FS, T_max=900.0):
        self.pid = PID(Kp, Ki, 0.0, dt, -T_max, T_max)

    def update(self, v_ref, k):
        # more speed needed -> driving torque -> negative Trwy
        return -self.pid.update(v_ref - forward_speed(k))


class RollController:
    """PID on the roll angle q9 acting on the steering torque.  To roll to
    the right the bike is steered to the LEFT first (counter-steer), hence a
    positive torque for a positive roll error."""

    def __init__(self, Kp=300.0, Ki=450.0, Kd=60.0, dt=1 / FS, T_max=150.0,
                 rate=1.2, tau=0.15, i_band=0.08):
        self.pid = PID(Kp, Ki, Kd, dt, -T_max, T_max, i_band)
        self.shaper = SetpointShaper(rate, tau, dt)
        self.ref = 0.0

    def update(self, roll_target, k):
        self.ref = self.shaper.update(roll_target)
        return self.pid.update(self.ref - k["q"][8], k["u"][8])


# --------------------------------------------------------------------------
# 4.7 engine torque, Table 6.1 gear ratios
# --------------------------------------------------------------------------
@dataclass
class Powertrain:
    """Engine torque map and transmission.

    The torque curves are DIGITISED from Figs. 4.20 and 4.21 of the thesis
    (accuracy about +-1 N m / +-2 %); gear tooth numbers are Table 6.1.
    """
    rpm: np.ndarray = field(default_factory=lambda: np.arange(4000, 15501, 500.0))
    T_wot: np.ndarray = field(default_factory=lambda: np.array(
        [36, 38, 45, 47, 46.5, 49, 51, 51.5, 55, 56, 56.5, 59, 61, 61, 61, 62, 63, 62.5, 61,
         59.5, 58, 57, 55.5, 52.5]))
    T_closed_lo: float = -7.5        # N m at 4000 rpm  (Fig. 4.20)
    T_closed_hi: float = -23.0       # N m at 15500 rpm
    thr: np.ndarray = field(default_factory=lambda: np.array(
        [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 100.0]))
    pct: np.ndarray = field(default_factory=lambda: np.array(
        [0, 2, 4, 7, 12, 22, 38, 55, 66, 73, 78.5, 83, 87, 90, 93, 95, 97, 98, 99, 100.0]))
    rev_limit: float = 15500.0       # torque fades to closed-throttle over the next 300 rpm
    gears: tuple = ((12, 32), (16, 31), (18, 29), (22, 31), (23, 29), (24, 28))
    primary: tuple = (36, 76)
    final: tuple = (14, 42)

    def ratio(self, gear):
        """Engine speed / rear wheel speed in the given gear (1..6)."""
        g = self.gears[gear - 1]
        return (self.primary[1] / self.primary[0]) * (g[1] / g[0]) * (self.final[1] / self.final[0])

    def engine_rpm(self, wheel_speed, gear):
        return abs(wheel_speed) * self.ratio(gear) * 60 / (2 * np.pi)

    def closed(self, rpm):
        return np.interp(rpm, [4000, 15500], [self.T_closed_lo, self.T_closed_hi])

    def engine_torque(self, rpm, throttle):
        """Torque [N m] from the map of Fig. 4.22: closed-throttle torque
        plus the throttle-dependent share of the span up to WOT."""
        share = np.interp(100 * np.clip(throttle, 0, 1), self.thr, self.pct) / 100
        share = share * np.clip((self.rev_limit + 300.0 - np.asarray(rpm)) / 300.0, 0.0, 1.0)   # soft rev limiter
        Tc = self.closed(rpm)
        return Tc + share * (np.interp(rpm, self.rpm, self.T_wot) - Tc)

    def throttle_for(self, torque, rpm):
        """Throttle position (0..1) that gives the requested engine torque."""
        grid = np.linspace(0, 1, 201)
        return float(np.interp(torque, self.engine_torque(rpm, grid), grid))

    def axle_torque(self, engine_torque, gear):
        """Rear axle torque in the model's sign convention (drive < 0)."""
        return -engine_torque * self.ratio(gear)


def brake_torque(T_brake, spin, w0=2.0):
    """Friction brake: axle torque of magnitude T_brake opposing the wheel
    rotation, smoothed around standstill so a locked wheel is not driven
    backwards.  Positive for a forward-rolling wheel (spin < 0)."""
    return T_brake * np.tanh(-spin / w0)


# --------------------------------------------------------------------------
# 4.13 crash avoidance
# --------------------------------------------------------------------------
def _wheel_slip(k, wheel):
    """Slip ratio as in Figs. 4.38 / 4.39: (V_wheel - V_axle) / V_axle with
    V_wheel = spin rate x contact radius of the tyre profile at the current
    camber and V_axle the forward speed of the axle in the ground frame."""
    if wheel == "rear":
        r, spin, heading, Jv = k["r_D"] - k["r_T"], k["u"][5], k["R_M"][:, 0], k["Jv_D"]
    else:
        r, spin, heading, Jv = k["r_G"] - k["r_S"], k["u"][4], k["R_H"][:, 0], k["Jv_G"]
    v_axle = float((Jv @ k["u"]) @ heading)
    v_wheel = -spin * np.linalg.norm(r)
    return (v_wheel - v_axle) / max(abs(v_axle), 1.0), v_wheel, v_axle


@dataclass
class TractionControl:
    """Fig. 4.38.  Positive rear slip above a roll-dependent target is
    scaled by Ktc and subtracted from the engine torque."""
    Ktc: float = 600.0                                  # N m per unit slip [E]
    roll_deg: tuple = (0.0, 20.0, 40.0, 55.0)           # target table [E]
    target: tuple = (0.10, 0.08, 0.05, 0.03)
    enabled: bool = True
    slip: float = 0.0
    error: float = 0.0
    reduction: float = 0.0

    def update(self, k, engine_torque):
        self.slip, _, _ = _wheel_slip(k, "rear")
        tgt = np.interp(abs(np.degrees(k["q"][8])), self.roll_deg, self.target)
        self.error = max(self.slip - tgt, 0.0)
        self.reduction = self.Ktc * self.error if self.enabled else 0.0
        return engine_torque - self.reduction


@dataclass
class ABS:
    """Fig. 4.39 for one wheel.  Only negative slip is considered.  When the
    slip passes the normal target the strategy becomes active and works
    against a stricter target until the slip has recovered.  The brake
    torque is multiplied by  1 + Kabs * (slip - target)  (clipped to 0..1).
    The front strategy is disabled close to full fork extension (wheelie)."""
    wheel: str = "front"
    Kabs: float = 2.0                # value of the thesis' example
    target_normal: float = -0.05     # value of the thesis' example
    target_strict: float = -0.02     # [E]
    q1_disable: float = 0.115        # fork extension above which ABS is off [E]
    enabled: bool = True
    active: bool = False
    slip: float = 0.0
    factor: float = 1.0

    def update(self, k, brake_torque):
        self.slip, _, _ = _wheel_slip(k, self.wheel)
        s = min(self.slip, 0.0)
        off = (not self.enabled) or (self.wheel == "front" and k["q"][0] > self.q1_disable)
        if off:
            self.active, self.factor = False, 1.0
            return brake_torque
        if not self.active and s < self.target_normal:
            self.active = True
        elif self.active and s >= self.target_strict:
            self.active = False
        if self.active:
            err = s - self.target_strict
            self.factor = float(np.clip(1.0 + self.Kabs * err, 0.0, 1.0))
        else:
            self.factor = 1.0
        return brake_torque * self.factor


# --------------------------------------------------------------------------
# discrete-time simulation
# --------------------------------------------------------------------------
def simulate(system, x0, n, controller=None, dt=1 / FS, method="heun", log=None, stop=None):
    """Integrate ``system`` (a BikeSystem) for n samples.

    controller(i, t, k, st, x) -> dict of extra inputs (e.g. Tsteer, Trwy,
    Tfwy), evaluated once per sample and held over the step (zero-order
    hold, like the thesis' discrete model).  ``log(i, t, k, st, x, ctl)``
    may return a dict of scalars that is collected.  Returns (t, X, logs).
    method: 'heun' (2 evaluations per step), 'rk4' or 'euler'.
    """
    x = np.array(x0, float)
    X = np.empty((n + 1, len(x))); X[0] = x
    t = dt * np.arange(n + 1)
    logs = {}
    for i in range(n):
        k = system.model.config(x[:NQ], x[NQ:2 * NQ])
        ctl, st = {}, None
        if controller is not None or log is not None:
            _, st = system.inputs(t[i], k, lagged=x[2 * NQ:])
        if controller is not None:
            ctl = controller(i, t[i], k, st, x) or {}
        if log is not None:
            for key, val in (log(i, t[i], k, st, x, ctl) or {}).items():
                logs.setdefault(key, np.full(n, np.nan))[i] = val
        f = lambda tt, xx: system.rhs(tt, xx, extra=ctl)
        try:
            k1 = f(t[i], x)
            if method == "euler":
                x = x + dt * k1
            elif method == "heun":
                x = x + dt / 2 * (k1 + f(t[i] + dt, x + dt * k1))
            else:
                k2 = f(t[i] + dt / 2, x + dt / 2 * k1); k3 = f(t[i] + dt / 2, x + dt / 2 * k2)
                x = x + dt / 6 * (k1 + 2 * k2 + 2 * k3 + f(t[i] + dt, x + dt * k3))
        except Exception:                      # model 'crash' (non-finite state)
            X[i + 1:] = np.nan
            break
        X[i + 1] = x
        if not np.isfinite(x).all() or (stop is not None and stop(x)):
            X[i + 2:] = np.nan
            break
    return t, X, logs


# --------------------------------------------------------------------------
# 4.12 the model as an observer: Kalman filter and gyro-driven steering
# --------------------------------------------------------------------------
class KalmanFilter:
    """The recursion printed in Section 4.12 (predictor form):

        s_k     = R + C P C^T
        K_k     = A P C^T s_k^-1
        x_{k+1} = A x_k + B u_k + K_k (y_k - C x_k)
        P_{k+1} = A P A^T + Q - K_k C P A^T
    """

    def __init__(self, P0, Q, R):
        self.P, self.Q, self.R = np.array(P0, float), np.array(Q, float), np.array(R, float)
        self.K = None

    def gain(self, A, C):
        P = self.P
        s = self.R + C @ P @ C.T
        self.K = A @ P @ C.T @ np.linalg.inv(s)
        self.P = A @ P @ A.T + self.Q - self.K @ C @ P @ A.T
        self.P = 0.5 * (self.P + self.P.T)
        return self.K


@dataclass
class GyroSteer:
    """Steering torque that forces the model to follow the recorded motion
    (Fig. 4.36):

        T_steer = g1 (w1 - w1_hat) + g2 (w2 - w2_hat) + g3 (w3 - w3_hat)
                  + g0 (roll - roll_hat)

    The first three terms are the rate-gyro errors of the thesis.  Rate
    feedback alone leaves the slow capsize mode of this model marginally
    unstable, so the recorded roll angle (output 8 of the C matrix) is
    used as well -- g0 is an ADDITION to Fig. 4.36; set g0 = 0 for the
    thesis' structure.

    Signs for the model's axes: more measured roll rate to the right needs
    counter-steer to the left (g1 > 0, g0 > 0); more measured yaw rate to
    the left needs the estimate to lean left, i.e. torque to the right
    (g2 < 0)."""
    g1: float = 60.0
    g2: float = 0.0
    g3: float = 0.0
    g0: float = 300.0
    T_max: float = 150.0

    def update(self, w_meas, w_hat, roll_meas=0.0, roll_hat=0.0):
        e = np.asarray(w_meas) - np.asarray(w_hat)
        T = self.g1 * e[0] + self.g2 * e[1] + self.g3 * e[2] + self.g0 * (roll_meas - roll_hat)
        return float(np.clip(T, -self.T_max, self.T_max))


def run_observer(system, x0, data, dt=1 / FS, kalman=True, steer=None, q_ws=2500.0, r_ws=0.04,
                 n_sched=80, torque_gain=1.0, log=None):
    """Run the model as an observer driven by recorded data (Fig. 4.36).

    data : dict of arrays sampled at dt with the recorded inputs
           'Trwy', 'Tfwy' (axle torques) and measurements 'u5', 'u6'
           (wheel speeds), 'gyro' (n x 3) and optionally 'roll'.
    The model is stepped with the recorded torques (times ``torque_gain`` to
    emulate a calibration error); the steering torque comes from
    :class:`GyroSteer`; if ``kalman`` the wheel speeds are corrected with the
    gain of :class:`KalmanFilter`, where A = I + dt * A_c is the thesis-form
    system matrix (4.38) re-scheduled every ``n_sched`` samples and the
    measurement rows are those of u5 and u6 in the output matrix C (4.11).
    q_ws: variance of the unmodelled wheel angular acceleration [(rad/s^2)^2]
    (process noise Q = q_ws dt^2 on u5, u6); r_ws: measurement noise
    variance of the wheel speeds [(rad/s)^2].
    Returns (t, X, logs).
    """
    steer = steer or GyroSteer()
    n = len(data["u5"]) - 1
    m = system.model
    # thesis state order x = [u1, q1, ..., u11, q11]; rows of C for u5, u6
    C = np.zeros((2, 2 * NQ)); C[0, 8] = 1.0; C[1, 10] = 1.0
    Q = np.zeros((2 * NQ, 2 * NQ)); Q[8, 8] = Q[10, 10] = q_ws * dt**2
    kf = KalmanFilter(np.zeros((2 * NQ, 2 * NQ)), Q, r_ws * np.eye(2))
    state = dict(A=None)

    def controller(i, t, k, st, x):
        w_hat = body_rates(k)
        roll_meas = data["roll"][i] if "roll" in data else k["q"][8]
        return {"Tsteer": steer.update(data["gyro"][i], w_hat, roll_meas, k["q"][8]),
                "Trwy": torque_gain * data["Trwy"][i], "Tfwy": torque_gain * data["Tfwy"][i]}

    x = np.array(x0, float)
    X = np.empty((n + 1, len(x))); X[0] = x
    t = dt * np.arange(n + 1)
    logs = {}
    for i in range(n):
        q, u = x[:NQ], x[NQ:2 * NQ]
        k = m.config(q, u)
        _, st = system.inputs(t[i], k, lagged=x[2 * NQ:])
        ctl = controller(i, t[i], k, st, x)
        if log is not None:
            for key, val in (log(i, t[i], k, st, x, ctl) or {}).items():
                logs.setdefault(key, np.full(n, np.nan))[i] = val
        f = lambda tt, xx: system.rhs(tt, xx, extra=ctl)
        try:
            k1 = f(t[i], x)
            xn = x + dt / 2 * (k1 + f(t[i] + dt, x + dt * k1))        # A x + B u (model step)
        except Exception:
            X[i + 1:] = np.nan
            break
        if kalman:
            if i % n_sched == 0:
                state["A"] = np.eye(2 * NQ) + dt * m.state_space(q, u)["A"]
            K = kf.gain(state["A"], C)
            innov = np.array([data["u5"][i] - u[4], data["u6"][i] - u[5]])
            dx = K @ innov                                            # thesis state order
            xn[NQ:2 * NQ] += dx[0::2]
            xn[:NQ] += dx[1::2]
        x = xn
        X[i + 1] = x
        if not np.isfinite(x).all():
            X[i + 2:] = np.nan
            break
    return t, X, logs
