"""Trim and linearisation utilities built on the model and force blocks."""
from __future__ import annotations

import numpy as np
from scipy.optimize import least_squares

from .kinematics import make_q, NQ
from .model import Motorcycle, make_inputs, IIN


def static_trim(model: Motorcycle, forces, q9=0.0, q11=0.0):
    """Static equilibrium on its wheels (bike held at roll q9, steer q11).

    Solves the four in-plane equations (r = 1..4) for q1..q4.  Returns
    (q, u_in, residual of all 11 equations): the residuals of the roll and
    steer equations are the holding torques a rider/stand must supply.
    """
    def res(z):
        q = make_q(q1=z[0], q2=z[1], q3=z[2], q4=z[3], q9=q9, q11=q11)
        k = model.config(q)
        uin = forces.inputs(0.0, k, damping=False)
        return (model.input_matrix(k) @ uin)[:4] / 1e3
    p = model.p
    z0 = [0.08, 0.5 * (p.q2_top + p.q2_bottom) + 0.05, 0.006, 0.007]
    sol = least_squares(res, z0, xtol=1e-14, ftol=1e-14, gtol=1e-14)
    q = make_q(q1=sol.x[0], q2=sol.x[1], q3=sol.x[2], q4=sol.x[3], q9=q9, q11=q11)
    k = model.config(q)
    uin = forces.inputs(0.0, k, damping=False)
    return q, uin, model.input_matrix(k) @ uin


def linearise(model: Motorcycle, input_fn, q0, u0, h=1e-6):
    """Numerical Jacobian of the closed-loop state derivative
    x_dot = f(x), x = [q, u], including the state-dependent force blocks
    (the 'missing' suspension/tyre dynamics of the Hammerstein A matrix)."""
    x0 = np.concatenate([q0, u0])
    f = lambda x: model.rhs(0.0, x, input_fn)
    n = len(x0)
    J = np.zeros((n, n))
    for i in range(n):
        d = np.zeros(n); d[i] = h
        J[:, i] = (f(x0 + d) - f(x0 - d)) / (2 * h)
    return J


def rolling_spin_rates(k, u):
    """Wheel spin rates u5, u6 for which the wheel-fixed points at the
    contacts have no longitudinal velocity (free rolling, zero slip)."""
    u = u.copy()
    for col, pt, heading in ((5, "T", k["R_M"][:, 0]), (4, "S", k["R_H"][:, 0])):
        a = k["Jv_" + pt].T @ heading            # d(v . heading)/du
        u[col] = 0.0
        u[col] = -(a @ u) / a[col]
    return u


def steady_turn(model: Motorcycle, forces, V, radius, turn="right"):
    """Steady-state cornering trim without a tyre model.

    The rear reference point O moves on a circle of the given radius at
    speed V, all relative speeds are zero and both wheels roll freely.
    Unknowns (11): q1..q4, roll q9, steer q11, the lateral tyre forces
    Ffwy, Frwy, the rear longitudinal force Frwx with its axle torque Trwy,
    and the rider's steering torque.  Equations (12): the eleven equations
    of motion with the centripetal u_dot, plus zero lateral velocity of the
    front contact point (kinematic steering).  Solved by least squares; the
    front-wheel spin equation is satisfied identically.
    """
    p = model.p
    sgn = -1.0 if turn == "right" else 1.0           # yaw rate: + = left
    yaw = sgn * V / radius
    c = IIN

    def evaluate(z):
        q = make_q(q1=z[0], q2=z[1], q3=z[2] * 0.1, q4=z[3] * 0.1,
                   q9=z[4], q11=z[5] * 0.1)
        u = np.zeros(NQ)
        u[6], u[9] = V, yaw                           # O moves along n1 (psi = 0)
        u = rolling_spin_rates(model.config(q, u), u)
        k = model.config(q, u)
        uin = forces.inputs(0.0, k, damping=False)
        uin[c["Ffwy"]], uin[c["Frwy"]], uin[c["Frwx"]] = z[6:9] * 1e3
        uin[c["Trwy"]], uin[c["Tsteer"]] = z[9] * 1e3, z[10] * 1e2
        ud = np.zeros(NQ)
        ud[7] = -V * yaw              # d/dt (V m1) = -V psi_dot n3 at psi = 0
        r = model.mass_matrix(k) @ ud + model.bias(k) - model.input_matrix(k) @ uin
        slip = (k["Jv_S"] @ u) @ k["R_H"][:, 2] / V
        return np.concatenate([r / 1e3, [10 * slip]]), (q, u, uin, k)

    z0 = np.array([0.08, 0.15, 0.06, 0.07, -sgn * np.arctan(V**2 / (p.g * radius)),
                   sgn * 1.39 / radius * 10, 0, 0, 0, 0, 0], float)
    sol = least_squares(lambda z: evaluate(z)[0], z0, xtol=1e-15, ftol=1e-15, gtol=1e-15)
    r, (q, u, uin, k) = evaluate(sol.x)
    return dict(q=q, u=u, u_in=uin, k=k, residual=r, yaw_rate=yaw)


# ==========================================================================
# complete vehicle: multibody model + force blocks + Magic Formula tyres
# ==========================================================================
class BikeSystem:
    """Motorcycle model with suspension blocks, Magic Formula tyres with
    relaxation, optional aerodynamic drag, chain and steering damper.

    State  x = [q (11), u (11), Fx_f, Fy_f, Fx_r, Fy_r]  -- the last four are
    the lagged tyre shear forces of Section 5.2.16 (model axes: Fy to the
    right).  ``controls(t, k, st)`` may return a dict of additional inputs,
    e.g. {"Tsteer": .., "Trwy": .., "Tfwy": ..}.
    """
    NX = 2 * NQ + 4

    def __init__(self, model, forces, tyres, drag=None, chain=None,
                 c_steer=0.0, relaxation=True, controls=None):
        self.model, self.forces, self.tyres = model, forces, tyres
        self.drag, self.chain, self.c_steer = drag, chain, c_steer
        self.relaxation, self.controls = relaxation, controls

    def inputs(self, t, k, lagged=None, extra=None, damping=True):
        uin = self.forces.inputs(t, k, damping=damping)
        uin, st = self.tyres.inputs(k, uin, forces=lagged if self.relaxation else None)
        q, u = k["q"], k["u"]
        if self.drag is not None:
            v = (k["Jv_A"] @ u) @ k["R_M"][:, 0]
            uin[IIN["Fdrag"]] = self.drag.aero(v)
        uin[IIN["Tsteer"]] -= self.c_steer * u[10]
        ctl = dict(extra or {})
        if self.controls is not None:
            ctl.update(self.controls(t, k, st))
        for name, val in ctl.items():
            uin[IIN[name]] += val
        if self.chain is not None:
            uin[IIN["Tsay"]] += self.chain.swingarm_torque(q[1], uin[IIN["Trwy"]])
        return uin, st

    def rhs(self, t, x, extra=None):
        """State derivative.  ``extra``: dict of additional inputs held
        constant by a discrete-time controller (see okane.controls)."""
        q, u, lag = x[:NQ], x[NQ:2 * NQ], x[2 * NQ:]
        k = self.model.config(q, u)
        uin, st = self.inputs(t, k, lagged=lag, extra=extra)
        ud = self.model.accelerations(q, u, uin, k)
        if self.relaxation:
            dlag = self.tyres.relaxation_rates(st, lag)
        else:
            dlag = np.zeros(4)
        return np.concatenate([u, ud, dlag])

    def lag_state(self, k):
        st = self.tyres.steady(k)
        return np.array([st["front"]["Fx"], st["front"]["Fy"], st["rear"]["Fx"], st["rear"]["Fy"]])

    # ------------------------------------------------------------------
    def steady_state(self, V, roll=0.0, z0=None):
        """Steady cornering (or straight running for roll = 0) at forward
        speed V of the rear reference point and prescribed roll angle.

        Unknowns (11): q1..q4, yaw rate, steer angle, lateral velocity of the
        rear reference point, front and rear longitudinal slip, steering
        torque, rear axle torque.  The front axle torque is zero.  Returns a
        dict with the full state ``x`` and derived quantities.
        """
        m, g = self.model, self.model.p.g

        def evaluate(z):
            q = make_q(q1=z[0], q2=z[1], q3=z[2] * 0.01, q4=z[3] * 0.01, q9=roll, q11=z[5] * 0.1)
            yaw, vy = z[4], z[6]
            u = np.zeros(NQ)
            u[6], u[7], u[9] = V, vy, yaw
            u = rolling_spin_rates(m.config(q, u), u)
            u[4] *= (1.0 + z[10] * 0.01)
            u[5] *= (1.0 + z[7] * 0.01)
            k = m.config(q, u)
            uin, st = self.inputs(0.0, k, lagged=None if not self.relaxation else self.lag_state(k),
                                  extra={"Tsteer": z[8] * 10, "Trwy": z[9] * 100}, damping=False)
            ud = np.zeros(NQ)
            ud[6], ud[7] = yaw * vy, -yaw * V
            r = m.mass_matrix(k) @ ud + m.bias(k) - m.input_matrix(k) @ uin
            return r / 1e3, (q, u, uin, k, st)

        if z0 is None:
            yaw0 = -g * np.tan(roll) / V * 0.85
            z0 = np.array([0.08, 0.15, 0.9, 0.9, yaw0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        sol = least_squares(lambda z: evaluate(z)[0], z0, xtol=1e-15, ftol=1e-15, gtol=1e-15)
        r, (q, u, uin, k, st) = evaluate(sol.x)
        x = np.concatenate([q, u, self.lag_state(k)])
        z = sol.x
        return dict(x=x, q=q, u=u, u_in=uin, k=k, tyres=st, residual=r, z=z,
                    yaw_rate=z[4], steer=q[10], Tsteer=z[8] * 10 - self.c_steer * 0.0, Trwy=z[9] * 100,
                    alpha_f=np.arctan(st["front"]["alpha"]), alpha_r=np.arctan(st["rear"]["alpha"]),
                    delta_k=k["delta_k"], radius=(V / z[4] if abs(z[4]) > 1e-9 else np.inf))

    # ------------------------------------------------------------------
    def jacobian(self, x, h=1e-6):
        """d(rhs)/dx by central differences."""
        n = len(x)
        J = np.zeros((n, n))
        for i in range(n):
            d = np.zeros(n); d[i] = h * max(1.0, abs(x[i]) * 1e-3)
            J[:, i] = (self.rhs(0.0, x + d) - self.rhs(0.0, x - d)) / (2 * d[i])
        return J

    def modes(self, x, tol=1e-4):
        """Eigenvalues/eigenvectors of the linearised system without the
        cyclic co-ordinates (wheel angles, position).  The yaw angle q10 must
        stay: u7, u8 are velocity components in the inertial frame, so a
        change of heading at fixed (u7, u8) is a side-slip.  The rotational
        symmetry shows up as zero eigenvalues."""
        J = self.jacobian(x)
        keep = [i for i in range(self.NX) if i not in (4, 5, 6, 7)]      # q5 q6 q7 q8
        lam, vec = np.linalg.eig(J[np.ix_(keep, keep)])
        return lam, vec, keep


STATE_NAMES = [f"q{i}" for i in range(1, 12)] + [f"u{i}" for i in range(1, 12)] + ["Fxf", "Fyf", "Fxr", "Fyr"]


def lateral_modes(system: BikeSystem, V, x=None, max_decay=60.0):
    """Out-of-plane modes of straight running at speed V.

    Returns a list of (eigenvalue, label) with label in {'weave', 'wobble',
    'capsize', 'real', 'osc'}; in-plane modes (bounce, pitch, hop) and the
    zero eigenvalues are removed.  Classification by frequency and by which
    of roll / steer dominates -- adequate for conventional motorcycles.
    """
    if x is None:
        x = system.steady_state(V, 0.0)["x"]
    lam, vec, keep = system.modes(x)
    nm = [STATE_NAMES[i] for i in keep]
    ix = lambda names: [nm.index(n) for n in names]
    out = []
    for l, v in zip(lam, vec.T):
        a = np.abs(v)
        lat, inp = (a[ix(["q9", "q10", "q11"])]**2).sum(), (a[ix(["q1", "q2", "q3", "q4"])]**2).sum()
        if lat <= inp or l.imag < -1e-9 or abs(l) < 1e-3 or l.real < -max_decay:
            continue
        if abs(l.imag) < 1e-6:
            label = "capsize" if abs(l.real) < 5 and a[nm.index("q9")] > a[nm.index("q11")] else "real"
        else:
            f = l.imag / (2 * np.pi)
            label = "weave" if f < 6.0 else "wobble"
        out.append((l, label))
    return sorted(out, key=lambda t: (t[0].imag, -t[0].real))
